import os.path
import json
from threading import*
import time

d={} 

# timeout is optional you can continue by passing two arguments without timeout

def create(key,value,timeout=0):
    if key in d:
        print("error: this key already exists") #Error message_1
    else:
        if(key.isalpha()):
            if len(d)<(1024*1020*1024) and value<=(16*1024*1024): #constraints for file size less than 1GB and Json object value less than 16KB 
                if timeout==0:
                    l=[value,timeout]
                else:
                    l=[value,time.time()+timeout]
                if len(key)<=32: #constraints for input key_name capped at 32chars
                    d[key]=l
                    j=json.dumps(d)
                    print("Do you want to add a path? If YES please enter 1 If not enter 0 ")
                    n=int(input("Enter your choice "))
                    if n==1:

                        path=input("Enter desired path  ")
                        filename=input("Enter filename  ")
                        cname=os.path.join(path,filename+".json")
                        f=open(cname,"w")
    
                        f.write(j)
                        f.close()
                    else:
                        with open('MyFile.json','w') as f:
                            f.write(j)
                            f.close()
                    print("Record stored")
            else:
                print("error: Memory limit exceeded!! ")#Error message_2
        else:
            print("error: Invalid key_name!! key_name must contain only alphabets and no special characters or numbers ")#error message3
       


def read(key):
    print()
    print("File reading mode activated")
    print()
    print("Have you entered desired path while creating the file if yes Enter 1 or else 0")
    n=int(input("Enter your choice  "))
    if n==1:

        path=input("Enter desired path  ")
        filename=input("Enter filename  ")
        print()
        cname=os.path.join(path,filename+".json")
        with open(cname,'r') as newdata:
            jd=json.load(newdata)
    else:    

        with open('MyFile.json','r') as newdata:
            jd=json.load(newdata)
        
    if key not in jd:
        print("error: given key does not exist in database. Please enter a valid key") #error message4
    else:
        b=jd[key]
        

        if b[1]!=0:
            if time.time()<b[1]:
                
                print(key,":",b[0])
            else:
                print("error: time-to-live of",key,"has expired") #Error message_5
        else:
            print(key,":",b[0])
            

def delete(key):
    print()
    print("File deleting mode activated")
    print()
    print("Have you entered desired path while creating the file if yes Enter 1 or else 0")
    n=int(input("Enter your choice  "))
    print()
    if n==1:

        path=input("Enter desired path  ")
        filename=input("Enter filename  ")
        cname=os.path.join(path,filename+".json")
        with open(cname) as nd:
            jdata=json.load(nd)
    else:
        with open('MyFile.json') as nd:
            jdata=json.load(nd)
    if key not in jdata:
        print("error: given key does not exist in database. Please enter a valid key") #Error message_4
    else:
        b=jdata[key]
        if b[1]!=0:
            if time.time()<b[1]:
                 
                del jdata[key]
                print("Key is successfully deleted")
            else:
                print("error: time-to-live of",key,"has expired") #Error message_5
        else:
            del jdata[key]
            print("key is successfully deleted")
    if n==1:
        with open(cname,'w') as nd:
            jdata=json.dump(jdata,nd)
    else:
        with open('MyFile.json','w') as nd:
            jdata=json.dump(jdata,nd)



